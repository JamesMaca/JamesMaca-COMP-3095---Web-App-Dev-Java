rootProject.name = "discovery-service"
