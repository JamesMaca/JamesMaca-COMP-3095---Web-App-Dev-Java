CREATE DATABASE "inventory-service"

GRANT ALL PRIVILEGES ON DATABASE "inventory-service" to "admin"