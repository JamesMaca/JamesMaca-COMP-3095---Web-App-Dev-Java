package ca.gbc.comment.dto;

import ca.gbc.comment.model.CommentItem;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CommentRequest {

    private List<CommentItem> commentItemListDto = new ArrayList<>();

}
