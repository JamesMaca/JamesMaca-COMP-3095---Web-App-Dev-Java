package ca.gbc.comment.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Table(name="comment")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Comment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private List<CommentItem> commentResponseList;

}
