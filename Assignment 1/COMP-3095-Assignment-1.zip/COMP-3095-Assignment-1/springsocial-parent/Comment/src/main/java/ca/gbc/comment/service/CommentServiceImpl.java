package ca.gbc.comment.service;

import ca.gbc.comment.dto.CommentRequest;
import ca.gbc.comment.model.Comment;
import ca.gbc.comment.model.CommentItem;
import ca.gbc.comment.repository.CommentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.function.Function;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class CommentServiceImpl implements CommentService{

    private final CommentRepository commentRepository;

    @Override
    public void makeComment(CommentRequest commentRequest) {
        Comment comment = new Comment();
        List<CommentItem> commentItemList = (List<CommentItem>) commentRequest.getCommentItemListDto().stream().map((Function<? super CommentItem, ? extends CommentItem>) this::mapToModel).toList();
        comment.setCommentResponseList(commentItemList);
        commentRepository.save(comment);
        log.info("Comment {} is saved", comment.getId());
    }

    private CommentItem mapToModel(CommentItem commentItem) {
        CommentItem commentItem1 = new CommentItem();
        commentItem1.setContent(commentItem.getContent());
        return commentItem;
    }
}
