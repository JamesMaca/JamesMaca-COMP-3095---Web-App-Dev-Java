CREATE TABLE comment (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    commentResponseList JSON
);

CREATE TABLE comment_item (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    content VARCHAR(255) NOT NULL,
    comment_id BIGINT,
    FOREIGN KEY (comment_id) REFERENCES comment(id)
);