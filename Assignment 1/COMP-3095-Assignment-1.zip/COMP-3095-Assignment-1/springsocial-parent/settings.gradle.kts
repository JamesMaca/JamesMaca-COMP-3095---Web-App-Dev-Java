rootProject.name = "springsocial-parent"

include("Post", "User", "Comment")