package ca.gbc.post.dto;

import lombok.AllArgsConstructor;
import org.apache.catalina.User;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Document(value = "post")
public class PostRequest {
    private User user;
    private String title;
    private String content;
    private Date dateCreated;
}
