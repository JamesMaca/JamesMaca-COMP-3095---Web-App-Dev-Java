package ca.gbc.post.service;

import ca.gbc.post.dto.PostRequest;
import ca.gbc.post.dto.PostResponse;
import ca.gbc.post.model.Post;
import ca.gbc.post.repository.PostRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
@Slf4j
public class PostServiceImpl implements PostService{

    private final PostRepository postRepository;
    private final MongoTemplate mongoTemplate;

    @Override
    public void createPost(PostRequest postRequest) {
        log.info("Creating Post {}!", postRequest.getTitle());

        Post newPost = Post.builder()
//                .user(postRequest.getUser())
                .title(postRequest.getTitle())
                .content(postRequest.getContent())
                .dateCreated(postRequest.getDateCreated())
                .build();

        postRepository.save(newPost);

        log.info("Post {} was created and saved!", newPost.getId());

    }

    @Override
    public List<PostResponse> getAllPosts() {
        log.info("Returning all posts!");
        List<Post> post = postRepository.findAll();
        return post.stream().map(this::mapToPostResponse).toList();
    }

    private PostResponse mapToPostResponse(Post post){

        return PostResponse.builder()
                .id(post.getId())
//                .user(post.getUser())
                .title(post.getTitle())
                .content(post.getContent())
                .dateCreated(post.getDateCreated())
                .build();

    }


}
