package ca.gbc.post.service;

import ca.gbc.post.dto.PostRequest;
import ca.gbc.post.dto.PostResponse;

import java.util.List;

public interface PostService {

    void createPost(PostRequest postRequest);

    List<PostResponse> getAllPosts();
}
